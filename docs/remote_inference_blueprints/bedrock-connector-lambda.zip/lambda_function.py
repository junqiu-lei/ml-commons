import json
import requests
from requests_aws4auth import AWS4Auth
import boto3
import cfnresponse
from urllib.parse import urlparse

def lambda_handler(event, context):
    
    print("event: " + str(event))
    
    request_type = event['RequestType']
    if request_type == 'Update' or request_type == 'Delete':
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {}, context.log_stream_name)
        return {
            "statusCode": 200
        }

    host = event['ResourceProperties']['AOSEndpoint']

    region = context.invoked_function_arn.split(':')[3]
    service = 'es'
    session = boto3.Session()
    credentials = session.get_credentials()
    endpoint = host.split("://")[1]

    awsauth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        region,
        service,
        session_token=credentials.token,
    )
    
    if host[-1] != '/':
        host += '/'

    path = '_plugins/_ml/connectors/_create' # the OpenSearch API endpoint
    
    url = host + path

    model_endpoint = event['ResourceProperties']['ModelEndpoint']
    print("model_endpoint: " + model_endpoint)
    
    payload = {
        "name": "Bedrock Connector: embedding",
        "description": "The connector to bedrock embedding model",
        "version": 1,
        "protocol": "aws_sigv4",
        "credential": {
            "roleArn": event['ResourceProperties']['AOSRoleArn']
        },
        "parameters": {
            "region": region,
            "service_name": "bedrock"
        },
        "actions": [
            {
                "action_type": "predict",
                "method": "POST",
                "headers": {
                    "content-type": "application/json",
                    "x-amz-content-sha256": "required",
                },
                "url": model_endpoint,
                "request_body": "{ \"inputText\": \"${parameters.inputText}\" }",
                "pre_process_function": "\n    StringBuilder builder = new StringBuilder();\n    builder.append(\"\\\"\");\n    String first = params.text_docs[0];\n    if (first.contains(\"\\\"\")) {\n      first = first.replace(\"\\\"\", \"\\\\\\\"\");\n    }\n    if (first.contains(\"\\\\t\")) {\n      first = first.replace(\"\\\\t\", \"\\\\\\\\\\\\t\");\n    }\n    if (first.contains('\n')) {\n      first = first.replace('\n', '\\\\n');\n    }\n    builder.append(first);\n    builder.append(\"\\\"\");\n    def parameters = \"{\" +\"\\\"inputText\\\":\" + builder + \"}\";\n    return  \"{\" +\"\\\"parameters\\\":\" + parameters + \"}\";",
                "post_process_function": "\n      def name = \"sentence_embedding\";\n      def dataType = \"FLOAT32\";\n      if (params.embedding == null || params.embedding.length == 0) {\n        return params.message;\n      }\n      def shape = [params.embedding.length];\n      def json = \"{\" +\n                 \"\\\"name\\\":\\\"\" + name + \"\\\",\" +\n                 \"\\\"data_type\\\":\\\"\" + dataType + \"\\\",\" +\n                 \"\\\"shape\\\":\" + shape + \",\" +\n                 \"\\\"data\\\":\" + params.embedding +\n                 \"}\";\n      return json;\n    "
            }
        ]
    }

    print("payload for create connector: " + str(payload))
    headers = {"Content-Type": "application/json"}
    print("url for create connector: " + url)
    response = requests.post(url, auth=awsauth, json=payload, headers=headers)
    print("response for create connector: " + str(response))
    responseData = {}
    if response.status_code == 200:
        print("response status code 200 for creating connector")
        invoke_results = response.json()
        responseData['model_endpoint'] = model_endpoint
        responseData['connector_id'] = invoke_results["connector_id"]
        mode_id = ""
        mode_id = register(invoke_results["connector_id"], host, awsauth)
        if mode_id != "":
            responseData['model_id'] = mode_id
        else:
            return {
                "statusCode": 500,
                "body": "model register failed",
            }

        invoke_results['model_id'] = responseData['model_id']

        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData, context.log_stream_name)
        return {
            "statusCode": 200,
            "body": json.dumps(invoke_results),
        }
    else:
        print("status code not 200 for creating connector")
        responseData['bedrock_endpoint'] = model_endpoint
        responseData['connector_id'] = ""
        responseData['model_id'] = ""
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData, context.log_stream_name)
        return {
            "statusCode": response.status_code,
            "body": response.text,
        }

def register(connector_id, host, awsauth):
    if connector_id == "":
        return ""
    model_group_id = register_model_group(connector_id, host, awsauth)
    if model_group_id == "":
        return ""
    else:
        return register_model(connector_id, host, awsauth, model_group_id)

def register_model_group(connector_id, host, awsauth):
    path = '_plugins/_ml/model_groups/_register'
    url = host + path
    payload = {
        "name": "Bedrock Model for connector " + connector_id,
        "description": "Bedrock Model for connector " + connector_id,
    }
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, auth=awsauth, json=payload, headers=headers)
    print("response for register model group: " + str(response))
    if response.status_code == 200:
        status = response.json()["status"]
        print("status: " + status)
        if status != "CREATED":
            return ""
        model_group_id = response.json()["model_group_id"]
        print("model group registered: " + model_group_id)
        import time
        time.sleep(1)
        
        return model_group_id
    else:
        return ""

def register_model(connector_id, host, awsauth, model_group_id):
    path = '_plugins/_ml/models/_register?deploy=true'
    url = host + path
    payload = {
        "name": "Bedrock Model for connector " + connector_id,
        "function_name": "remote",
        "description": "Bedrock Model for connector " + connector_id,
        "connector_id": connector_id,
        "model_group_id": model_group_id
    }
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, auth=awsauth, json=payload, headers=headers)
    print("response for register model: " + str(response))
    
    if response.status_code == 200:
        task_id = response.json()["task_id"]
        print("model registered")
        print("task_id: " + task_id)
        import time
        time.sleep(1)
        
        return get_model_from_task(task_id, host, awsauth)
    else: 
        return ""

def get_model_from_task(task_id, host, awsauth):
    path = "_plugins/_ml/tasks/" + task_id
    url = host + path
    headers = {"Content-Type": "application/json"}
    
    print("url for get model from task: " + url)
    response = requests.get(url, auth=awsauth, json={}, headers=headers)
    print("response for get model from task: " + str(response))

    if response.status_code == 200:
        return response.json()["model_id"]
    else:
        return ""
